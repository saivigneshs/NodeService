var nodemailer = require("nodemailer");
var express = require("express");
var app = express();

app.get("/url", (req, res, next) => {
 main().catch(console.error);
 res.json(["Tony","Lisa","Michael","Ginger","Food"]);
});


async function main() {
    // Generate test SMTP service account from ethereal.email
    // Only needed if you don't have a real mail account for testing
    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        //host: 'smtp.ethereal.email',
        host: 'ext-nam1.smtp.philips.com',
        //port: 587,
        port: 25,
       /* auth: {
            user: 'minnie.volkman80@ethereal.email',
            pass: 'uVccdQ3hrZB3j2BYrt'
        }, */
        logger : true,
        //secure: true,
        debug: true,
        //ignoreTLS:false
    });

    // send mail with defined transport object
    let info = await transporter.sendMail({
        from: '"CIM Reporting" <CIM_DevOps@Philips.onmicrosoft.com>', // sender address
        to: "aditya.sirohi@philips.com", // list of receivers
        subject: "AIM Reporting Alarm Load", // Subject line
        html: '<h1>Patient Alarm Load Report</h1><img src="cid:unique@nodemailer.com" alt="Test" />' +
            '<h1>Filters: Institution: French C03, Units: ACU, Date: Apr 1, Alarm: All, Severity: Cyan, Bed: All, Label: All</h1>'
       /* attachments: [{
            filename: 'pal.png',
            path: __dirname+'/pal.png',
            cid: 'unique@nodemailer.com' //my mistake was putting "cid:logo@cid" here!
        }]*/
    });

    console.log("Message sent: %s", info.messageId);
    // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

    // Preview only available when sending through an Ethereal account
    console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
}

app.listen(3000, () => {
 console.log("Server running on port 3000");
});